#!/bin/bash
dmenu_run -b -nb '#151617' -nf '#d8d8d8' -sb '#d8d8d8' -sf '#151617'
